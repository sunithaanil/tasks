<?php
	include "db.php";
	$action = $_POST['action'];

	if ($action == 'add') {
			$task_name = $_POST['task_name'];
			$description = $_POST['description'];
			$status = $_POST['status'];
		$id = isset($_POST['id']) ? $_POST['id'] : 0;
			if($id > 0) {
				$sql = "UPDATE tasks task_name='".$task_name."', description = '".$description."', status = '".$status."' where id =".$id." ";
			} else {
				$sql = "insert into tasks (task_name, description, status) values('".$task_name."', '".$description."','".$status."')";
			}
			$result = $conn->query($sql);

	} else if ($action == 'get') {
		$id = isset($_POST['id']) ? $_POST['id'] : 0;
		$sql = "SELECT * FROM tasks";
		if ($id > 0) {
			$sql .= " where id = ".$id;
		}
		$result = $conn->query($sql);
		$data = array();
	    while($row = $result->fetch_assoc()) {
	        $data[] = $row;
	    }
	    echo json_encode($data);
	    exit;
	} else if ($action == 'delete') {
			
		$id = isset($_POST['id']) ? $_POST['id'] : 0;
		
				$sql = "Delete from tasks where id=".$id." ";
			
			$result = $conn->query($sql);

	} else if ($action == 'sendMail') {
		ini_set("smtp_port", 25);
		$id = isset($_POST['id']) ? $_POST['id'] : 0;
		$sql = "SELECT * FROM tasks";
		if ($id > 0) {
			$sql .= " where id = ".$id;
		}
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		$task_name = $row['task_name'];
		$description = $row['description'];
		$headers = "From: suniani2011@gmail.com";

		mail($_POST['email'],$task_name,$description,$headers);
		//mail($_POST['email'], 'suniani2011@gmail.com', $msg);
	}



?>