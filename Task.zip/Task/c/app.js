function submitTask() {
	if ($("#task_name").val() == '') {
		alert("Enter Task Name");
	} else if ($("#description").val() == '') {
		alert("Enter Task Desc");
	} else if ($("#status").val() == '') {
		alert("Select Status");
	} else {
		$.ajax({
			        url : "../m/task.php",
			        type: "POST",
			        data : {task_name : $("#task_name").val(),description : $("#description").val(),status : $("#status").val(),action:'add'},
			        success:function(data, textStatus, jqXHR) 
			        {
			        	$("#id").val('');
			        	$("#task_name").val('');
			        	$("#description").val('');
			        	$("#status").val('');
			            getTasks();
			        },
			        error: function(jqXHR, textStatus, errorThrown) 
			        {
			            //if fails      
			        }
			    });
	}


}
function getTasks() {
	$.ajax(
	    {
	        url : "../m/task.php",
	        type: "POST",
	        data : {id : $("#id").val(),task_name : $("#task_name").val(),description : $("#description").val(),status : $("#status").val(),action:'get'},
	        success:function(res, textStatus, jqXHR) 
	        {
	        	var s_no = 0;
	        	var data1 = jQuery.parseJSON(res);
	            var table = '<table class="table">';
	            table+= '<tr><td>S.No</td><td>Task Name</td><td>Task Description</td><td>Status</td><td>Email</td><td>Option</td>';
	            $.each( data1, function( key, value ) {
	              s_no++;
				  table+= '<tr><td>'+s_no+'</td><td>'+value.task_name+'</td><td>'+value.description+'</td><td>'+value.status+'</td><td><a data-toggle="modal" data-target="#myModal" onclick="openMailModal('+value.id+')">Send</a></td><td><a onclick="editTask('+value.id+')">Edit</a><br/><a onclick="deleteTask('+value.id+')">Delete</a></td>';

				});

	            table+= '</table>';
	            $("#taskList").html(table);
	        },
	        error: function(jqXHR, textStatus, errorThrown) 
	        {
	            //if fails      
	        }
	    });
}
function editTask(id) {
	$.ajax(
	    {
	        url : "../m/task.php",
	        type: "POST",
	        data : {id : id, action:'get'},
	        success:function(data1, textStatus, jqXHR) 
	        {
	        	var data1 = jQuery.parseJSON(data1);
	        	var res = data1[0];
	        	console.log(res);
	        	$("#id").val(res.id);
	        	$("#task_name").val(res.task_name);
	        	$("#description").val(res.description);
	        	$("#status").val(res.status);
	        },
	        error: function(jqXHR, textStatus, errorThrown) 
	        {
	            //if fails      
	        }
	    });

}
function deleteTask(id) {
	$.ajax(
	    {
	        url : "../m/task.php",
	        type: "POST",
	        data : {id : id, action:'delete'},
	        success:function(data1, textStatus, jqXHR) 
	        {
	        	getTasks();
	        },
	        error: function(jqXHR, textStatus, errorThrown) 
	        {
	            //if fails      
	        }
	    });

}
function openMailModal(id) {
	$("#id").val(id);
}
function sendMail() {
	$.ajax(
	    {
	        url : "../m/task.php",
	        type: "POST",
	        data : {id : $("#id").val(),email : $("#email").val(), action:'sendMail'},
	        success:function(data1, textStatus, jqXHR) 
	        {
	        		$("#id").val('');
	        	alert("Mail Sent Successfully");
	        	$("#myModal").modal("hide");
	        },
	        error: function(jqXHR, textStatus, errorThrown) 
	        {
	            //if fails      
	        }
	    });

}
getTasks();